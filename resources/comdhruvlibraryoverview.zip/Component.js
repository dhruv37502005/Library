sap.ui.define(["sap/ovp/app/Component"],function(e){"use strict";return e.extend("com.dhruv.libraryoverview.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map