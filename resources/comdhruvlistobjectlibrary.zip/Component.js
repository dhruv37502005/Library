sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("com.dhruv.listobjectlibrary.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map